
public class Alumno {
      int calificacion;
      String nombre;
      static double coutaSemestral;
      public Alumno(int cal,String nomb){
          calificacion=cal;
          nombre = nomb;
      }
      public void muestraInformacionAlumno(){
          System.out.print("Nombre: " + nombre);
          System.out.println("     Calificación: " + calificacion);
          muestraCoutaSemestral();
          
      }
      
      public static void muestraCoutaSemestral(){
          System.out.println("La cuota semestral es de: " + coutaSemestral);
      }
}
