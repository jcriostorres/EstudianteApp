
public class Principal {
    public static void main(String args[]){
        Calificiaciones califGrupo = new Calificiaciones();
        Alumno alumnoUno = new Alumno(100,"Juan");
        Alumno alumnoDos = new Alumno(95,"María");
        Alumno alumnoTres = new Alumno(80,"Jorge"); 
        
        Alumno.coutaSemestral=1000;
        
        alumnoUno.muestraInformacionAlumno();
        alumnoDos.muestraInformacionAlumno();
        alumnoTres.muestraInformacionAlumno();
        
        
        Alumno.coutaSemestral=500;
        
        alumnoUno.muestraInformacionAlumno();
        alumnoDos.muestraInformacionAlumno();
        alumnoTres.muestraInformacionAlumno();
        
        
    }
}
