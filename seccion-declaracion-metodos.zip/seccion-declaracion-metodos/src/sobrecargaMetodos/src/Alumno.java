
public class Alumno {
      private double calificacion;
      private String nombre;
      private int edad;
      static double coutaSemestral;
       
      public Alumno(){
          
      }
      public Alumno(String nomb){
          nombre=nomb;
      }
      
      public void setDatosAlumno(String nomb){
          nombre=nomb;
      }
      
      public void setDatosAlumno(double cal){
          calificacion=cal;
      }
      
      public void setDatosAlumno(String nomb, int ed){
          nombre=nomb;
          edad=ed;
      }
      public void setDatosAlumno(String nomb, int ed, double cal){
          nombre=nomb;
          edad=ed;
          calificacion=cal;
      }
      
      
      public static void muestraCoutaSemestral(){
          System.out.println(" La cuota semestral es de: " + coutaSemestral);
      }
      
      public void muestraInformacionAlumno(){
          System.out.print("Nombre: " + nombre);
          System.out.print("     Calificación: " + calificacion);
          System.out.print("     Edad: " + edad);
          muestraCoutaSemestral();
      }
}
