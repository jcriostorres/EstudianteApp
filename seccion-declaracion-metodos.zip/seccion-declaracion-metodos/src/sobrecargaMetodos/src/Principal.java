
public class Principal {
    public static void main(String args[]){
        Alumno alumnoUno= new Alumno();
        alumnoUno.muestraInformacionAlumno();
        
        Alumno alumnoDos = new Alumno("Jorge Robles");
        alumnoDos.muestraInformacionAlumno();
        
        //cambio al alumno Uno
        alumnoUno.setDatosAlumno("María Hernández");
        alumnoUno.setDatosAlumno(95);
        alumnoUno.muestraInformacionAlumno();
    }
}
