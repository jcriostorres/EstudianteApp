
public class Principal {

    public static void main(String args[]) {
        if (args.length <= 0) {
            System.out.println("No se enviaron parametros");
        }
        for (int i = 0; i < args.length; i++) {
            if (isNumber(args[i])) {
                System.out.println("Parametro " + i + "  =  " + args[i] + " es un número");
            } else {
                System.out.println("Parametro " + i + "  =  " + args[i] + " No es un número");
            }
        }
    }

    public static boolean isNumber(String cadena) {

        if (cadena.isEmpty() || cadena == null) {
            return false;
        }
        int i = 0;
        if (cadena.charAt(i) == '-') {
            if (cadena.length() > 1) {
                i++;
            } else {
                return false;
            }
        }
        for (; i < cadena.length(); i++) {
            if (!Character.isDigit(cadena.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
