
public class ClasePrincipal {
    
    public static void main (String args[]){
        ClaseConDosMetodos  objeto = new ClaseConDosMetodos();
        objeto.calcula();
    }
    
    
}
